import tkinter as tk
import sys

LARGE_FONT= ("Verdana", 12)
NORM_FONT = ("Helvetica", 10)
SMALL_FONT = ("Helvetica", 8)

popup = 0

def enderlite():
    global popup
    sys.exit()
    popup.destroy()

def message(msg, end):
    global popup
    popup = tk.Tk()
    popup.wm_title("Info")
    popup.geometry("250x75")
    label = tk.Label(popup, text=msg, font=NORM_FONT)
    label.pack(side="top", fill="x", pady=10)
    if end:
        B1 = tk.Button(popup, text="Close", command = enderlite)
    else:
        B1 = tk.Button(popup, text="Close", command = popup.destroy)
    B1.pack()
    popup.mainloop()